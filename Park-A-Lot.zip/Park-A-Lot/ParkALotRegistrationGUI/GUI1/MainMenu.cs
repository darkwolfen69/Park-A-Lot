﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace GUI1
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void Walkinbtn_Click(object sender, EventArgs e)
        {
            DriveInParkingAssignment ticket = new DriveInParkingAssignment();
            ticket.Show();
        }

        private void Reservedbtn_Click(object sender, EventArgs e)
        {
            Park_Alot.ReservationForm enterMemberNumber = new Park_Alot.ReservationForm();
            enterMemberNumber.ShowDialog();
            ParkDownOrUp upDown = new ParkDownOrUp();
            upDown.ShowDialog();
            
            MainMenu menu = new MainMenu();
            menu.Close();
        }


    }
}
