﻿namespace GUI1
{
    partial class EnterRegistrationNumber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtbxEntrRegNum = new System.Windows.Forms.TextBox();
            this.btnSubmitRegNum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(421, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please enter your registration number.";
            // 
            // txtbxEntrRegNum
            // 
            this.txtbxEntrRegNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxEntrRegNum.Location = new System.Drawing.Point(193, 102);
            this.txtbxEntrRegNum.Name = "txtbxEntrRegNum";
            this.txtbxEntrRegNum.Size = new System.Drawing.Size(256, 35);
            this.txtbxEntrRegNum.TabIndex = 1;
            // 
            // btnSubmitRegNum
            // 
            this.btnSubmitRegNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitRegNum.Location = new System.Drawing.Point(333, 167);
            this.btnSubmitRegNum.Name = "btnSubmitRegNum";
            this.btnSubmitRegNum.Size = new System.Drawing.Size(116, 72);
            this.btnSubmitRegNum.TabIndex = 2;
            this.btnSubmitRegNum.Text = "Submit";
            this.btnSubmitRegNum.UseVisualStyleBackColor = true;
            this.btnSubmitRegNum.Click += new System.EventHandler(this.btnSubmitRegNum_Click);
            // 
            // EnterRegistrationNumber
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 281);
            this.Controls.Add(this.btnSubmitRegNum);
            this.Controls.Add(this.txtbxEntrRegNum);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "EnterRegistrationNumber";
            this.ShowIcon = false;
            this.Text = "Enter Registration Number";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbxEntrRegNum;
        private System.Windows.Forms.Button btnSubmitRegNum;
    }
}