﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace GUI1
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void Walkinbtn_Click(object sender, EventArgs e)
        {
            ParkingTicket ticket = new ParkingTicket();
            ticket.ShowDialog();
        }

        private void Reservedbtn_Click(object sender, EventArgs e)
        {
            EnterRegistrationNumber enterNumber = new EnterRegistrationNumber();
            enterNumber.Show();
        }


    }
}
