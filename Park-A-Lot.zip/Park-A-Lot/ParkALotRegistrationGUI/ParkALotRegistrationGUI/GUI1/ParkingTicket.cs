﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI1
{
    public partial class ParkingTicket : Form
    {
        public ParkingTicket()
        {
            InitializeComponent();
        }

        private void lblParkingSpot_TextChanged(object sender, EventArgs e)
        {
            //
            //  The text of this lable will need to change according to the available parking spot.
            //  This lable will be used for Drive-in customers as well as Resgistered customers who
            //  do not have a reservation and opt to park on the Drive-In floor.
            //
        }

        private void ParkingTicket_Load(object sender, EventArgs e)
        {
            MainMenu menu = new MainMenu();
            menu.Close();
        }

        


    }
}
