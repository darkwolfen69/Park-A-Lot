﻿namespace GUI1
{
    partial class ParkingTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblThankYou = new System.Windows.Forms.Label();
            this.lblParkingSpot = new System.Windows.Forms.Label();
            this.lblMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblThankYou
            // 
            this.lblThankYou.AutoSize = true;
            this.lblThankYou.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThankYou.Location = new System.Drawing.Point(15, 28);
            this.lblThankYou.Name = "lblThankYou";
            this.lblThankYou.Size = new System.Drawing.Size(493, 32);
            this.lblThankYou.TabIndex = 0;
            this.lblThankYou.Text = "Thank you for choosing Park-A-Lot!";
            // 
            // lblParkingSpot
            // 
            this.lblParkingSpot.AutoSize = true;
            this.lblParkingSpot.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParkingSpot.Location = new System.Drawing.Point(212, 165);
            this.lblParkingSpot.Name = "lblParkingSpot";
            this.lblParkingSpot.Size = new System.Drawing.Size(98, 73);
            this.lblParkingSpot.TabIndex = 1;
            this.lblParkingSpot.Text = "---";
            this.lblParkingSpot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblParkingSpot.TextChanged += new System.EventHandler(this.lblParkingSpot_TextChanged);
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsg.Location = new System.Drawing.Point(16, 78);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(480, 52);
            this.lblMsg.TabIndex = 2;
            this.lblMsg.Text = "Please take you reciept printed below \r\nand pull forward to your designated parki" +
    "ng spot.";
            this.lblMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ParkingTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 269);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.lblParkingSpot);
            this.Controls.Add(this.lblThankYou);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "ParkingTicket";
            this.ShowIcon = false;
            this.Text = "Drive-In Parking Assignment";
            this.Load += new System.EventHandler(this.ParkingTicket_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblThankYou;
        private System.Windows.Forms.Label lblParkingSpot;
        private System.Windows.Forms.Label lblMsg;
    }
}