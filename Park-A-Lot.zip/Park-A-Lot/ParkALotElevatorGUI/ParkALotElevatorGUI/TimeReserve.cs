﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkALotElevatorGUI
{
    public partial class TimeReserve : Form
    {
        private PremiumParking premiumParking;

        public TimeReserve()
        {
            InitializeComponent();
        }

        public TimeReserve(PremiumParking premiumParking)
        {
            // TODO: Complete member initialization
            this.premiumParking = premiumParking;
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            DateTime.MinValue.Equals(DateTime.Now);

            
            string start = startTime.Value.ToString();
            string end = endTime.Value.ToString();

            
             Reservation someReservation = new Reservation(this);
             this.Close();
             someReservation.Show();

        }
    }
}
