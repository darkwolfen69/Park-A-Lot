﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkALotElevatorGUI
{
    public partial class LicensePlate : Form
    {
        private DisplayScreen displayScreen;

        public LicensePlate()
        {
            InitializeComponent();
        }

        public LicensePlate(DisplayScreen displayScreen)
        {
            // TODO: Complete member initialization
            this.displayScreen = displayScreen;
            InitializeComponent();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            CustomerNumber visitingCustomer = new CustomerNumber(displayScreen);
            this.Close();
            visitingCustomer.Show();
        }


    }
}
