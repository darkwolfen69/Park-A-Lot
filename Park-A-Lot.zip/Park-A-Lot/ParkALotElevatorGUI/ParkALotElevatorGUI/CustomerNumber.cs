﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkALotElevatorGUI
{
    public partial class CustomerNumber : Form
    {
        private DisplayScreen displayScreen;

        public CustomerNumber()
        {
            InitializeComponent();
            button1.Click += GenerateNumber;
            button2.Click += GenerateNumber;
            button3.Click += GenerateNumber;
            button4.Click += GenerateNumber;
            button5.Click += GenerateNumber;
            button6.Click += GenerateNumber;
            button7.Click += GenerateNumber;
            button8.Click += GenerateNumber;
            button9.Click += GenerateNumber;
            button10.Click += GenerateNumber;
        }

        public CustomerNumber(DisplayScreen displayScreen)
        {
            // TODO: Complete member initialization
            this.displayScreen = displayScreen;
            InitializeComponent();
        }

        public void GenerateNumber(object sender, EventArgs e)
        {
            var buttonNumber = sender as Button;
            textBox1.Text += buttonNumber.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
