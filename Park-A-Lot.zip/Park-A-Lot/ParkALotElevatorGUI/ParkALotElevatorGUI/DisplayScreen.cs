﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkALotElevatorGUI
{
    public partial class DisplayScreen : Form
    {
        public DisplayScreen()
        {
            InitializeComponent();
            this.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LicensePlate newVehicle = new LicensePlate(this);
            newVehicle.Show();
            bn_pullForward.Hide();
            lb_displayHeader.Text = "Welcome to Park-A-Lot!";

        }
    }
}
