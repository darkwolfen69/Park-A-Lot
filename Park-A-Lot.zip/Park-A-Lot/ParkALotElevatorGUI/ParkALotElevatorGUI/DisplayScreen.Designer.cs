﻿namespace ParkALotElevatorGUI
{
    partial class DisplayScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_displayHeader = new System.Windows.Forms.Label();
            this.bn_pullForward = new System.Windows.Forms.Button();
            this.lb_displayInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_displayHeader
            // 
            this.lb_displayHeader.AutoSize = true;
            this.lb_displayHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_displayHeader.Location = new System.Drawing.Point(280, 47);
            this.lb_displayHeader.Name = "lb_displayHeader";
            this.lb_displayHeader.Size = new System.Drawing.Size(413, 36);
            this.lb_displayHeader.TabIndex = 0;
            this.lb_displayHeader.Text = "Welcome, please pull forward!";
            // 
            // bn_pullForward
            // 
            this.bn_pullForward.Location = new System.Drawing.Point(428, 354);
            this.bn_pullForward.Name = "bn_pullForward";
            this.bn_pullForward.Size = new System.Drawing.Size(130, 23);
            this.bn_pullForward.TabIndex = 1;
            this.bn_pullForward.Text = "Pull Forward.";
            this.bn_pullForward.UseVisualStyleBackColor = true;
            this.bn_pullForward.Click += new System.EventHandler(this.button1_Click);
            // 
            // lb_displayInfo
            // 
            this.lb_displayInfo.AutoSize = true;
            this.lb_displayInfo.Location = new System.Drawing.Point(315, 156);
            this.lb_displayInfo.Name = "lb_displayInfo";
            this.lb_displayInfo.Size = new System.Drawing.Size(0, 17);
            this.lb_displayInfo.TabIndex = 2;
            // 
            // DisplayScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 389);
            this.Controls.Add(this.lb_displayInfo);
            this.Controls.Add(this.bn_pullForward);
            this.Controls.Add(this.lb_displayHeader);
            this.Name = "DisplayScreen";
            this.Text = "Park-A-Lot";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_displayHeader;
        private System.Windows.Forms.Button bn_pullForward;
        private System.Windows.Forms.Label lb_displayInfo;
    }
}

