﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkALotElevatorGUI
{
    public partial class PremiumParking : Form
    {
        public PremiumParking()
        {
            InitializeComponent();
        }

       

        private void btnNo_Click(object sender, EventArgs e)
        {
            
            this.Close();
            // redirect to GetOut();

        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            TimeReserve timeReserve = new TimeReserve(this);
            // redirect to TimeReserve
            this.Close();
            timeReserve.Show();
            

        }
    }
}
